<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle="Sagas - $cfg[server_name]";
include ("header.inc.php");
?>
</div><div id="content">
<div class="top">Sagas</div>
<div class="mid">
<CENTER>
<input type="image" src="fotos/Sagas/saiyansaga.jpg" name="submit" alt="saiyansaga">
</CENTER>
<center>
</center>
<center>1: Resgate Chibi Gohan e Mate Raditz.</center>
<center>2: Converce com Kaito e Treine.</center>

<center>3: Mate Vegeta.</center>
<center>4: Acabou a Saga Sayan Va Para Saga Freeza.</center>
<center>-----------------------------\\------------------------------</center>
<CENTER>
<input type="image" src="fotos/Sagas/freezasaga.jpg" name="submit" alt="freezasaga">
</CENTER>
<center>
</center>
<center>1: Salve Dende e Mate Dodoria.</center>
<center>2: Encontre e Mate Zarbon.</center>

<center>3: Encontre e Mate as Forcas Especiais Ginyu. "Ginyu Squad".</center>
<center>4: Va a Nave de Freeza e Fale com Vegeta.</center>
<center>5: Mate o Capitan Ginyu Que Esta com o Corpo de Goku.</center>
<center>6: Mate Freeza e Fale com Nail.</center>
<center>7: Axe Forma 2 de Freeza Fale com Ele e E Mate o Freeza em Todas Suas Formas.</center>
<center>8: Va para o Npc Namekjin na cidade Principal e termine a Saga Freeza.</center>
<center>9: Acabou a Saga do Freeza Va Para Saga Cell.</center>
<center>-----------------------------\\------------------------------</center>
<CENTER>

<input type="image" src="fotos/Sagas/cellsaga.jpg" name="submit" alt="cellsaga">
</CENTER>
<center>
</center>
<center>1: Fale Com Future Trunks.</center>
<center>2: Fale com Metal Freeza e Mate-o.</center>
<center>3: Fale com o NPC C19 and C20 Na Cidade e Mate-o.</center>
<center>4: Encontre o Laboratorio do Dr Gero e pegue sua recompenca com os Npc Android 16 e 17.</center>
<center>5: Ajude Um Homen na Cidade do Norte que Esta em Perigo e Mate Cell.</center>
<center>6: Va Ate o C17, Mata-lo , Depois Mate Cell e Resgate Vegeta.</center>

<center>7: Fale Com Trunks Na casa Do Mestre-Kame.</center>
<center>8: Fale Com Cell No Seu Torneio. Mate os cell Jr e em seguida Mate Cell.</center>
<center>9: Acabou a Saga do Cell Va Para Saga Buu.</center>
<center>-----------------------------\\------------------------------</center>
<CENTER>
<input type="image" src="fotos/Sagas/buusaga.jpg" name="submit" alt="buusaga">
</CENTER>
<center>
</center>
<center>1: Fale Com Shin Na Sala Proxima Ao Torneio de Artes Marciais.</center>

<center>2: Va a Nave de Babidi e Mate Pui Pui, Yakon, Dabura e Majin Vegeta.</center>
<center>3: Mate O Majin Buu Gordo "Fat Buu".</center>
<center>4: Va Ate o Piccolo No Templo e Mate Fat Buu.</center>
<center>5: Converse Com Mr MoMo e Mate Buu.</center>
<center>6: Encontre Dende No Deserto e Mate Buu.</center>
<center>7: Mate Kid Buu.</center>
<center>8: Acabou a Saga do Buu Va Para Saga GT.</center>
<center>-----------------------------\\------------------------------</center>
<CENTER>

<input type="image" src="fotos/Sagas/gtsaga.jpg" name="submit" alt="gtsaga">
</CENTER>
<center>
</center>
<center>1: Va Ate o Templo de Kamissama fale com Uub e Mate-o.</center>
<center>2: Viaje Para Lude, Fale com Buyer e Pegue uma Esfera.</center>
<center>3: Viaje Para Zelta Fale com Sepru e Pegue uma Esfera.</center>
<center>4: Viaje Para Vegeta Fale com Saiyan e Pegue uma Esfera.</center>
<center>5: Viaje Para Premia Fale com Capitan e Pegue uma Esfera.</center>
<center>6: Viaje Para Namek Fale com Namekjin e Pegue uma Esfera.</center>

<center>7: Viaje Para M2 Fale com Giru e Pegue uma Esfera.</center>
<center>8: Viaje Para Gardia Fale com Soberman e Pegue uma Esfera.</center>
<center>9: Leve As 7 Esferas Para o Dende No Templo! De 7 Yes --> (hi,yes,yes,yes,yes,yes,yes,yes,bye).</center>
<center>10: Viaje Para Tsufur Fale com Bebi e Mate-o.</center>
<center>11: Mate Bebi Oozaru (MACACO).</center>
<center>12: Va Ate Super C17 e Mate-o.</center>
<center>13: Encontrar e Matar Ryan Shenlong.</center>
<center>14: Encontrar e Matar Chii-Shenlong.</center>
<center>15: Encontrar e Matar Uu Shenlong.</center>

<center>16: Encontrar e Matar Ryuu Shenlong.</center>
<center>17: Encontrar e Matar Suu Shenron.</center>
<center>18: Encontrar e Matar San Shenron.</center>
<center>19: Encontrar e Matar Li Shenron.</center>
<center>20: Va Ate Goku SSJ4 e Termine sua Saga GT.</center>
<center>21: Meus Parabens Voce Completou Todas as Sagas, Otima Aventura!</center>
<center>-----------------------------\\------------------------------</center>

</div>
<div class="bot">
<?php include ("footer.inc.php");?>