
<head><title>Hunter xGames</title>
<link rel="icon" type="image/png" href="skins/icon.png" />
<link href="skins/style.css" rel="stylesheet" type="text/css"/>
<font face="Segoe Ui">
<div id="top">
<center><a href="index.php">Inicio</a>&nbsp;&nbsp;
<a href="regras.php">Regras</a>&nbsp;&nbsp;
<a href="xat.php">Bate-Papo</a></center></div>
<div id="header"></div>
</head><body><font size="1"><br /></font>
<div id="mid"><font size="2">
<center><font color="red"><font size="5"><b>Hunter Xat</b></font></font></center>
<center><embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="540" height="405" name="chat" FlashVars="id=167800994&rl=Brazilian" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" /></center><br/><br/>
&bull; <font size="3"><b>Regras do Xat:</b></font><br/>
&bull; N&atildeo xingue.<br/>
&bull; N&atildeo pe&ccedil;a cargos.<br/>
&bull; N&atildeo divulgue nada.<br/>
&bull; N&atildeo se fassa de membros da staff.<br/>
&bull; N&atildeo fique com nomes [ADM], [GM].<br/>
&bull; Caso n&atildeo cumpra as Regras podera ser kickado ou levar ban de 1 hora a 48 horas.<br/>
&bull; Ou em ultimo caso ate Permanente.<br/>
</font></div>