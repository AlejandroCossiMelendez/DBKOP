<?php 
include ("include.inc.php");
$ptitle="Contato - $cfg[server_name]";
include ("header.inc.php");
?>
<div id="content">
<div class="top">Contato</div>
<div class="mid">
Nome: ADM Bianco</br>
Email: bianco.dbz@hotmail.com</br>
</br>
Nome: ADM Alisson</br>
Email: mauro.lira@hotmail.com</br>
</div>
<div class="bot">
<?php include ("footer.inc.php");?>
