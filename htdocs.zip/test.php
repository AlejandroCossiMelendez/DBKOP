<table cellpadding='0' cellspacing='0' width='100%' class='border'>

<tr>

<td background='themes/dbvictory/images/sbc.jpg' height='35' class='scapmain'>&nbsp;&nbsp;&nbsp;Logowanie</td>

</tr>

<tr>

<td class='side-body'>
<div align='center'>
	<form name='loginform' method='post' action='setuser.php'>
	Nazwa Uzytkownika<br>
	<input type='text' name='user_name' class='textbox' style='width:100px'><br>
	Haslo<br>
	<input type='password' name='user_pass' class='textbox' style='width:100px'><br>
	<input type='checkbox' name='remember_me' value='y'>Zapamietaj mnie<br><br>
	<input type='submit' name='login' value='Loguj' class='button'><br>
	</form>
	<br>
<img src='themes/dbvictory/images/bullet.gif' alt=''> <a href='lostpassword.php' class='side'>Zapomniane haslo?</a>
	</div>
</td>

</tr>

</table>