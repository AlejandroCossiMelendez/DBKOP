<?php 
include ("../include.inc.php");
require ('check.php');

phpinfo();
?>