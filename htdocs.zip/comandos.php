<?php 
include ("include.inc.php");
$ptitle="Home - $cfg[server_name]";
include ("header.inc.php");
?>
<div id="content">
    <div class="top">Comandos</div>
    <div class="mid">

<CENTER>
<b><font size="2"><font color="red">Comandos:</font></font></b><br />
/xpzbye (Tira Pz, Battle)<br/>
/xfragbye (Tira Flags)<br/>
!frags (Indica mortes injustificadas)<br />
!vote (Votar)<br />

saga (Mensagem que indica em qual saga voce esta)<br />

!online(Uma lista com todos que estao jogando)<br />
/gethouse<br />
!buyhouse<br />
<br />
<b><font size="2"><font color="red">Magias:</font></font></b><br />
power Down (Zera seu ki e almenta Kl(Ki Level))<br />
Share ki "nick" (Envia ki para um jogador)<br />
Sense "nick" (Senti o ki do jogador)<br />

power up (Recarrega seu ki)<br />

Tecnicas (Para ver todas as suas magias)<br />
<br />
<b><font size="2"><font color="red">Transformacoes:</font></font></b><br />
Mega Transform (Ssj5)<br />
Super Transform (Ssj6)<br />
Transforms (Shenron, Janemba, Gotenks)<br />
fusion (gotenks,goku e vegeta--gogeta ,goku e vegeta Gt-- gogeta ssj4)<br />
Revert(todos os outros)<br />
Transform (todos)<br />
Absorb (tsuful)<br />

Unabsorb (tsuful)<br />
Kaioken (Goku)<br />

Power Ball (vegeta,brolly)--(vegeta,brolly,bardock)<br />
Click (Gohan)<br />
</CENTER>

</div>
<div class="bot">
<?php include ("footer.inc.php");?>