<div style="text-align: left;">
<b>Conectados :
<!-- Inicio Codigo Visitas online gratis opromo.com  -->
<script language="Javascript" src="http://www.opromo.com/servicos/usuariosonline/useronline.php?site=sitewwwerrormuonlinerg3net&corfont1=9999FF&texto=8&formato=negrito&tipo=arial&tamanho=2&simbo=7" type="text/javascript"></script>
<!-- Fim Codigo Visitas online gratis opromo.com  -->
</b>
<div style="text-align: left;">

<b>Visitas :
<!-- in�cio do c�digo para o contador de visitas C�digoFonte.net -->
<script language="JavaScript" type="text/javascript" src="http://contador.codigofonte.net/log.php?id=119310&d=texto"></script>
<!-- final do c�digo para o contador de visitas C�digoFonte.net --></b></div>
<div style="text-align: left;">
</div>
<div style="text-align: left;">
<b>Seu Ip: <script type="text/javascript" src="http://www.whatsmyip.us/showipsimple.php"> </script></b></div></div>
