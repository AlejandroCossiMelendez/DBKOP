
<head><title>Hunter xGames</title>
<link rel="icon" type="image/png" href="skins/icon.png" />
<link href="skins/style.css" rel="stylesheet" type="text/css"/>
<font face="Segoe Ui">
<div id="top">
<center><a href="index.php">Inicio</a>&nbsp;&nbsp;
<a href="regras.php">Regras</a>&nbsp;&nbsp;
<a href="xat.php">Bate-Papo</a></center></div>
<div id="header"></div>
</head><body><font size="1"><br /></font>
<div id="mid">
<font size="2">
&bull; <font size="3"><b>Regras:</b></font></br>
&bull; N&atildeo use Hack.<br />
&bull; N&atildeo Divulgue outro Jogo.<br />
&bull; N&atildeo Pergunte como crie o Jogo.<br />
&bull; N&atildeo Crie chars com o Nome de Membros da Staff.<br />
&bull; N&atildeo Desrespeite Administradores ou Membros da Staff.<br />
&bull; Caso n&atildeo cumpra as Regras podera ser Kickado ou Levar Ban.<br />
&bull; As Regras acima sao para todos Jogos.<br />
&bull; Divirta-se.<br />
</font></div>