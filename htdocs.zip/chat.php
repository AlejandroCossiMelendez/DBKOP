<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle="Chat - $cfg[server_name]";
include ("header.inc.php");
?>
<div id="content">
<div class="top">Chat</div>
<div class="mid">
<center><b>Sem Xingar Por Favor ;)</center></b>
<center><b>Sem Divulgar Links Por Favor ;)</center></b>
<center><b>Sem Flood Por Favor ;)</center></b>
<center>
<img style="visibility:hidden;width:0px;height:0px;" border=0 width=0 height=0 src="http://c.gigcount.com/wildfire/IMP/CXNID=2000002.0NXC/bT*xJmx*PTEzMjg3NzIwMjgxMTgmcHQ9MTMyODc3MjExNDAwOSZwPTUzMTUxJmQ9Jmc9MSZvPWU1YTFiZjUxY2IzMzRjMjdhMjFj/MjE*YmM5MDk5MGI*.gif" /><embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" width="540" height="405" name="chat" FlashVars="id=166695719&rl=Brazilian" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" />

</center>
</div>
</div>
</div>
<?php include ("footer.inc.php");?>