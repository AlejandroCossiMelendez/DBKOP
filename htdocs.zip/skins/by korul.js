google_color_border = "AF0000";
google_color_bg = "464646";
google_color_link = "AF0000";
google_color_text = "000000";
google_color_url = "red";