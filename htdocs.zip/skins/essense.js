google_color_border = "525552";
google_color_bg = "e2e2e2";
google_color_link = "ffffff";
google_color_text = "333333";
google_color_url = "525552";