google_color_border = "101410";
google_color_bg = "101410";
google_color_link = "ffffff";
google_color_text = "333333";
google_color_url = "525552";