google_color_border = "fbfbfb";
google_color_bg = "fbfbfb";
google_color_link = "444444";
google_color_text = "000000";
google_color_url = "000000";