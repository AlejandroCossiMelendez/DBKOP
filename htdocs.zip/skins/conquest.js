google_color_border = "525552";
google_color_bg = "e9dccc";
google_color_link = "ffffff";
google_color_text = "333333";
google_color_url = "525552";