google_color_border = "ddebda";
google_color_bg = "ddebda";
google_color_link = "000000";
google_color_text = "000000";
google_color_url = "000000";