google_color_border = "323319";
google_color_bg = "45462c";
google_color_link = "baea5c";
google_color_text = "7e984b";
google_color_url = "7e984b";