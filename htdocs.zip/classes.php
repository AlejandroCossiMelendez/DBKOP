<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle="Home - $cfg[server_name]";
include ("header.inc.php");
?>
</div><div id="content">
<div class="top">Classes & Magias</div>
<div class="mid">

    
<CENTER>
<h1>Classes & Magias</h1>
</CENTER>


    <br /><br />

<CENTER>
<form target="pagseguro" action="fotos/classes e magias/local/bardock.jpg" method="post">
<input type="image" src="fotos/classes e magias/Bardock.gif" name="submit" alt="Bardock">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/brolly.jpg" method="post">
<input type="image" src="fotos/classes e magias/Brolly.gif" name="submit" alt="Brolly">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/buu.jpg" method="post">
<input type="image" src="fotos/classes e magias/Buu.gif" name="submit" alt="Buu">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/c17.jpg" method="post">
<input type="image" src="fotos/classes e magias/C 17.gif" name="submit" alt="C 17">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/c18.jpg" method="post">

<input type="image" src="fotos/classes e magias/C 18.gif" name="submit" alt="C 18">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/cell.jpg" method="post">
<input type="image" src="fotos/classes e magias/Cell.gif" name="submit" alt="Cell">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/chibitrunks.jpg" method="post">
<input type="image" src="fotos/classes e magias/Chibi Trunks.gif" name="submit" alt="Chibi Trunks">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/cooler.jpg" method="post">
<input type="image" src="fotos/classes e magias/Cooler.gif" name="submit" alt="Cooler">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/dende.jpg" method="post">
<input type="image" src="fotos/classes e magias/Dende.gif" name="submit" alt="Dende">
</form>

    <br /><br />

<CENTER>
<form target="pagseguro" action="fotos/classes e magias/local/Freeza.jpg" method="post">
<input type="image" src="fotos/classes e magias/Freeza.gif" name="submit" alt="Freeza">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Gohan.jpg" method="post">
<input type="image" src="fotos/classes e magias/Gohan.gif" name="submit" alt="Gohan">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Goku.jpg" method="post">
<input type="image" src="fotos/classes e magias/Goku.gif" name="submit" alt="Goku">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Goten.jpg" method="post">
<input type="image" src="fotos/classes e magias/Goten.gif" name="submit" alt="Goten">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Trunks.jpg" method="post">
<input type="image" src="fotos/classes e magias/Trunks.gif" name="submit" alt="Trunks">
</form>

<form target="pagseguro" action="fotos/classes e magias/local/Namekjin.jpg" method="post">
<input type="image" src="fotos/classes e magias/Namekjin.gif" name="submit" alt="Namekjin">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Tsuful.jpg" method="post">
<input type="image" src="fotos/classes e magias/Tsuful.gif" name="submit" alt="Tsuful">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Uub.jpg" method="post">
<input type="image" src="fotos/classes e magias/Uub.gif" name="submit" alt="Uub">
</form>
<form target="pagseguro" action="fotos/classes e magias/local/Vegeta.jpg" method="post">
<input type="image" src="fotos/classes e magias/Vegeta.gif" name="submit" alt="Vegeta">
</form>
</CENTER>

    <br /><br />

<CENTER>
<input type="image" src="fotos/classes e magias/estilos.jpg" name="submit" alt="Goku">
</CENTER>



</div>
<div class="bot">
<?php include ("footer.inc.php");?>