<?php 
include ("include.inc.php");
?>
<div>Escolha Um Jogo</div>
<img src="http://img692.imageshack.us/img692/1279/wodbobianco.png" width="49%" height="250" border="1" usemap="#Map1"/><map name="Map1" id="Map1"><area shape="rect" coords="0,0,500,292" href="notes.php" />
<img src="http://img703.imageshack.us/img703/8206/pbo.png" width="49%" height="250" border="1" usemap="#Map2"/><map name="Map2" id="Map2"><area shape="rect" coords="0,0,500,292" href="pokemon.php" />
<a href="http://otservlist.org/ots/1102066"><img src="http://signatures.otservlist.org/1102066_2.png" width="49%" alt="" style="border: 1px"></a>
<a href="http://otservlist.org/ots/1126571"><img src="http://signatures.otservlist.org/1126571_4.png" width="49%" alt="" style="border: 1px"></a>
</div>
<?php include ("footer.inc.php");?>