<head><title>DBF</title>
<link rel="icon" type="image/png" href="skins/icon.png" />
<link href="skins/style.css" rel="stylesheet" type="text/css"/>
<font face="Segoe Ui">
<div id="top">
<center><a href="index.php">Inicio</a>&nbsp;&nbsp;
<a href="regras.php">Regras</a>&nbsp;&nbsp;
<a href="xat.php">Bate-Papo</a></center></div>
<div id="header"></div>
</head><body><font size="1"><br /></font>
<div id="mid"><font size="2">
<center>Sej&atildeo bem vindos ao DBF</br>Para Downloads, Cria e Gerenciar Contas, Clique na imagem Abaixo.</center></br>
<div id="dbz"><a href="wodbo/index.php"><img src="Skins/dbz.png"></a></div>
<!--<div id=""><a href="/index.php"><img src="Skins/.png"></a></div>-->
</br></br></br></br></br></br></br>
<center>Divirta-se.</br>DBF Team.</center>
</font></div>