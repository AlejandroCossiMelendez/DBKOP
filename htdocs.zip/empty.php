<?php 
include ("include.inc.php");
$ptitle= "News - $cfg[server_name]";
include ("header.inc.php");
?>
<div id="content">
<div class="top">Server News</div>
<div class="mid">
Put your HTML content here!
</div>
<div class="bot"></div>
</div>
<?php include ("footer.inc.php");}?>