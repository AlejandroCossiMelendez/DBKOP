<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle= "Quests - $cfg[server_name]";
include ("header.inc.php");
?>
<div id="content">
<div class="top">Quests</div>
<div class="mid">
<center>
<font size=6><font color=black>.: Esferas Quest :.</FONT></font> 
</center>
<center><b>Nessa Quest voce tera que encontrar os "Guardioes" cada guardiao em seu nome esta o numero da esfera do dragao desejada Exemplo: Guardiao One, da esfera de 1 estrela.</b></center>
<center><b>Cada um dos 7 guardioes pedira algo em troca da esfera, primeira dica o guardiao one pedira 10 Golds.</b></center>
<center><b>Quando voce reunir as 7 esferas podera invocar "Shenlong" e faser 1 dos desejos.</b></center>
<center><font size=4><font color=red>Bom Jogo. HunterTeam</FONT></font> </center>
</div>
<div class="bot">
<?php include ("footer.inc.php");?>