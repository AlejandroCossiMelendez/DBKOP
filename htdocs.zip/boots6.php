<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle="Items - $cfg[server_name]";
include ("header.inc.php");
?>
</div>
</div><div id="content">
<div class="top">Items</div>
<div class="mid">
<center>
<font size=4><font color=green>.: Helmets :.</FONT></font> 
</center>
<CENTER>
<br />
<img src="fotos/Items/Helmets.jpg"/><br />
<br />
</CENTER>
<center>

<font size=4><font color=green>.: Armors :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Armors.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Legs :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Legs.jpg"/><br />
<br />
</CENTER>

<center>
<font size=4><font color=green>.: Boots :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Boots.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Bands :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Bands.jpg"/><br />
<br />

</CENTER>
<center>
<font size=4><font color=green>.: Ki Blasting :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Ki Blasting.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Gloves :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Gloves.jpg"/><br />

<br />
</CENTER>
<center>
<font size=4><font color=green>.: Guns :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Guns.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Swords :.</FONT></font>
</center>
<CENTER>
<br />

<img src="fotos/Items/Swords.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Outras Armas :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Outras Armas.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Itens De Quest :.</FONT></font>
</center>
<CENTER>

<br />
<img src="fotos/Items/Itens De Quest.jpg"/><br />
<br />
</CENTER>
<center>
<font size=4><font color=green>.: Itens Valiosos :.</FONT></font>
</center>
<CENTER>
<br />
<img src="fotos/Items/Itens Valiosos.jpg"/><br />
<br />
</CENTER>

</div>
<div class="bot">
<?php include ("footer.inc.php");?>