print "Content-Type: text/html\n\n";

print "OK";
