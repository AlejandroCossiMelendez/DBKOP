<noscript>
  <span id="javacheck" class="exception">
    Este sitio requiere que JavaScript esté habilitado para funcionar correctamente.
  </span>
</noscript>

<script type="text/javascript">
  // Oculta el aviso de "JavaScript requerido"
  document.getElementById('javacheck').style.display = 'none';
  <?php if (empty($error)) echo "document.getElementById('error')?.style.display = 'none';"; ?>
</script>

<footer id="footer" class="clearer">
  <span style="color: red; font-size: 0.9em;">
    Creado por Neto. &copy; Todos los derechos reservados.
  </span>
</footer>

<?php 
// Obtener tiempo final
$mtime = microtime();
$mtime = explode(" ", $mtime);
$mtime = $mtime[1] + $mtime[0];
$tend = $mtime;

// Calcular diferencia de tiempo de ejecución
$totaltime = ($tend - $tstart);

// Mostrar (descomentar si deseas visualizar)
// printf("Página generada en %.4f segundos\n", $totaltime);
?>

</body>
</html>
