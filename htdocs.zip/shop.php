<?php 
/*
    Copyright (C) 2007 - 2008  Nicaw

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License along
    with this program; if not, write to the Free Software Foundation, Inc.,
    51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/
include ("include.inc.php");
$ptitle="SHOP - $cfg[server_name]";
include ("header.inc.php");
?>
</div>
</div><div id="content">
<div style="width: 0%">

<form method="post" target="_new" action="https://pagseguro.uol.com.br/security/webpagamentos/webpagto.aspx" name="LOGIN" class="formulario" style="width: 450px; margin: 0 0 10px 0; float: left;">

<p>

<input type="hidden" name="email_cobranca" value="contato_hunter@hotmail.com">

<input type="hidden" name="tipo" value="CP"> 

<input type="hidden" name="moeda" value="BRL"> 

<input type="hidden" name="item_id_1" value="2000050"> 

<br><table border="2"><tbody><tr border="2"><td bgcolor="#505050" class="white"><strong>Nome do Seu Personagem (Sem erro):</strong></td></tr></tbody></table> 

<table border="2"><tbody><tr border="2"><td bgcolor="grey"><input type="text" name="item_descr_1"></td></tr></tbody></table><br> 

<input type="hidden" name="item_quant_1" value="1"> 

<br><table border="2"><tbody><tr border="2"><td width="153" bgcolor="#505050" class="white"><span class="style11 style4"><strong>Escolha Seu Item:</strong></span></td>

</tr></tbody></table> 

<table border="0"><tbody><tr border="2">

  <td width="96" bgcolor="grey"><label>

    <select name="item_valor_1" id="item_valor_1" tabindex="2">

      <option selected>Selecione</option>

      <option value="10,00">[Sword Of Fire - Atk 200 Def 80]R$ 10,00</option>

      <option value="5,00">[Red Senzu]R$ 5,00</option>

      <option value="10,00">[Sport Jacket - Def 200]R$ 10,00</option>  
   
      <option value="10,00">[1000 Golds]R$ 10,00</option>     

                                </select>

  </label></td>

</tr></tbody></table>
</td>
</tr>
<br> 

<br> 

<input type="hidden" name="item_frete_1" value="000"> 

<br> 

<table border="2"><tbody><tr border="2"><td bgcolor="#505050"><input type="submit" value="Finalizar Compra"></td></tr></tbody></table>


 

</p>

<div class="bot">
<?php include ("footer.inc.php");?>